Quality check, 5 November 2026

The CSV contains all 504 selected records, live values, published flags and numeric differences. Empty flag means no observation flag returned, not zero uncertainty. All available values matched; one missing value matched. Three records carry u (low reliability). No b flags were returned for the selection.

Eurostat API query: https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/isoc_sk_dskl_i21?lang=EN&indic_is=I_DSK2_BAB&unit=PC_IND
API updated field: 2026-04-17T11:00:00+0200

Metadata reviewed: indicator quality profile, plus 2025 national ICT-survey reports for Germany, Estonia and Romania. This does not reproduce sampling errors or audit all national reports.
